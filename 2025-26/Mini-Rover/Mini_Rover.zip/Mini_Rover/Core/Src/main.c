/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <ctype.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef enum {
    RPM_IDLE,
    RPM_MEASURING,
    RPM_READY
} RPM_State;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

//Motor Indices
#define Front_Left 0
#define Mid_Left 1
#define Back_Left 2

#define Front_Right 3
#define Mid_Right 4
#define Back_Right 5

#define ENCODER_PPR 1200

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
char rx_char;
volatile char rx_buffer[64];        // Holds the command string
volatile uint8_t rx_index = 0;
volatile uint8_t msg_ready = 0;
char main_buffer[64];

volatile int8_t motor_direction[6] = {0};
volatile uint32_t encoder_counts[6] = {0};
uint32_t last_speed_calc_tick[6] = {0};
double motor_rpm[6] = {0};

RPM_State rpm_state = RPM_IDLE;
int rpm_pending_motor = -1;
uint32_t rpm_window_start = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM3_Init(void);
/* USER CODE BEGIN PFP */
void update_motor (int index, int speed); //Updates the speed and direction of each motor
void serial_processing (char *buffer); //Parses serial commands to extract speed and direction
void calculate_rpm(int motor_id);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_TIM1_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
  HAL_UART_Receive_IT(&huart2, (uint8_t *)&rx_char, 1);

  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);
  __HAL_TIM_MOE_ENABLE(&htim1);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

	  if (msg_ready)
		  {
		  	  strncpy(main_buffer, (char*)rx_buffer, 64);
			  memset((void*)rx_buffer, 0, sizeof(rx_buffer));
			  msg_ready = 0;

			  char debug_msg[100];
			  sprintf(debug_msg, "\r\nSTM32 Received: '%s'\r\n", main_buffer);
			  HAL_UART_Transmit(&huart2, (uint8_t*)debug_msg, strlen(debug_msg), HAL_MAX_DELAY);

			  // Process the command
			  serial_processing(main_buffer);
			  memset(main_buffer, 0, sizeof(main_buffer));
		  }

	    if (rpm_state == RPM_MEASURING){
	        if ((HAL_GetTick() - rpm_window_start) >= 100){
	            // 100ms has elapsed, calculate and report
	            calculate_rpm(rpm_pending_motor);

	            const char *dir;
	            if      (motor_direction[rpm_pending_motor] ==  1) dir = "Forward";
	            else if (motor_direction[rpm_pending_motor] == -1) dir = "Backward";
	            else                                               dir = "Stopped";

	            char reply[80];
	            sprintf(reply, "\r\nMotor %d: %.1f RPM [%s]\r\n",
	                    rpm_pending_motor,
	                    (float)motor_rpm[rpm_pending_motor],
	                    dir);
	            HAL_UART_Transmit(&huart2, (uint8_t*)reply, strlen(reply), HAL_MAX_DELAY);

	            rpm_state = RPM_IDLE;
	            rpm_pending_motor = -1;
	        }
	    }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 83;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 999;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 83;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 999;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, M0_Fwd_Pin|M0_Back_Pin|M1_Fwd_Pin|M1_Back_Pin
                          |M2_Fwd_Pin|M2_Back_Pin|M3_Fwd_Pin|M3_Back_Pin
                          |M4_Fwd_Pin|M4_Back_Pin|M5_Fwd_Pin|M5_Back_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : M0_Fwd_Pin M0_Back_Pin M1_Fwd_Pin M1_Back_Pin
                           M2_Fwd_Pin M2_Back_Pin M3_Fwd_Pin M3_Back_Pin
                           M4_Fwd_Pin M4_Back_Pin M5_Fwd_Pin M5_Back_Pin */
  GPIO_InitStruct.Pin = M0_Fwd_Pin|M0_Back_Pin|M1_Fwd_Pin|M1_Back_Pin
                          |M2_Fwd_Pin|M2_Back_Pin|M3_Fwd_Pin|M3_Back_Pin
                          |M4_Fwd_Pin|M4_Back_Pin|M5_Fwd_Pin|M5_Back_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : M0_Phase_B_Pin M1_Phase_B_Pin M2_Phase_B_Pin M3_Phase_B_Pin
                           M4_Phase_B_Pin M5_Phase_B_Pin */
  GPIO_InitStruct.Pin = M0_Phase_B_Pin|M1_Phase_B_Pin|M2_Phase_B_Pin|M3_Phase_B_Pin
                          |M4_Phase_B_Pin|M5_Phase_B_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : M0_EXTI_Pin M1_EXTI_Pin M2_EXTI_Pin M3_EXTI_Pin
                           M4_EXTI_Pin M5_EXTI_Pin */
  GPIO_InitStruct.Pin = M0_EXTI_Pin|M1_EXTI_Pin|M2_EXTI_Pin|M3_EXTI_Pin
                          |M4_EXTI_Pin|M5_EXTI_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  HAL_NVIC_SetPriority(EXTI4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_IRQn);

  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
  void update_motor (int motor_id, int speed){
	  uint16_t is_backwards = (speed < 0); //Check for negative speed command
	  uint32_t magnitude = abs(speed);

	  // Duty Cycle = CRR / (ARR + 1)
	  //CRR = magnitude * (ARR + 1) / 100
	  //ARR set to 999 for 1kHz PWM frequency. Can be adjusted to avoid jerking.

	  uint16_t crr = magnitude * 10;

	  switch (motor_id) {
	  	  //Left side (0-2): timer 1

		  case Front_Left:

			  if (speed == 0){
				  HAL_GPIO_WritePin (GPIOC, M0_Fwd_Pin, 0);
				  HAL_GPIO_WritePin (GPIOC, M0_Back_Pin, 0);
				  motor_direction[Front_Left] = 0;
			  }
			  else if (!is_backwards){
				  HAL_GPIO_WritePin (GPIOC, M0_Fwd_Pin, 1);
				  HAL_GPIO_WritePin (GPIOC, M0_Back_Pin, 0);
				  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, crr);
				  motor_direction[Front_Left] = 1;
			  }
			  else{
				  HAL_GPIO_WritePin (GPIOC, M0_Fwd_Pin, 0);
				  HAL_GPIO_WritePin (GPIOC, M0_Back_Pin, 1);
				  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, crr);
				  motor_direction[Front_Left] = -1;
			  }

			  break;

		  case Mid_Left:
			  if (speed == 0){
				  HAL_GPIO_WritePin (GPIOC, M1_Fwd_Pin, 0);
				  HAL_GPIO_WritePin (GPIOC, M1_Back_Pin, 0);
				  motor_direction[Mid_Left] = 0;
			  }
			  else if (!is_backwards){
				  HAL_GPIO_WritePin (GPIOC, M1_Fwd_Pin, 1);
				  HAL_GPIO_WritePin (GPIOC, M1_Back_Pin, 0);
				  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, crr);
				  motor_direction[Mid_Left] = 1;
			  }
			  else{
				  HAL_GPIO_WritePin (GPIOC, M1_Fwd_Pin, 0);
				  HAL_GPIO_WritePin (GPIOC, M1_Back_Pin, 1);
				  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, crr);
				  motor_direction[Mid_Left] = -1;
			  }
			  break;

		  case Back_Left:
			  if (speed == 0){
				  HAL_GPIO_WritePin (GPIOC, M2_Fwd_Pin, 0);
				  HAL_GPIO_WritePin (GPIOC, M2_Back_Pin, 0);
				  motor_direction[Back_Left] = 0;
			  }
			  else if (!is_backwards){
				  HAL_GPIO_WritePin (GPIOC, M2_Fwd_Pin, 1);
				  HAL_GPIO_WritePin (GPIOC, M2_Back_Pin, 0);
				  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, crr);
				  motor_direction[Back_Left] = 1;
			  }
			  else{
				  HAL_GPIO_WritePin (GPIOC, M2_Fwd_Pin, 0);
				  HAL_GPIO_WritePin (GPIOC, M2_Back_Pin, 1);
				  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, crr);
				  motor_direction[Back_Left] = -1;
			  }
			  break;

		  case Front_Right:
			  if (speed == 0){
				  HAL_GPIO_WritePin (GPIOC, M3_Fwd_Pin, 0);
				  HAL_GPIO_WritePin (GPIOC, M3_Back_Pin, 0);
				  motor_direction[Front_Right] = 0;
			  }
			  else if (!is_backwards){
				  HAL_GPIO_WritePin (GPIOC, M3_Fwd_Pin, 1);
				  HAL_GPIO_WritePin (GPIOC, M3_Back_Pin, 0);
				  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, crr);
				  motor_direction[Front_Right] = 1;
			  }
			  else{
				  HAL_GPIO_WritePin (GPIOC, M3_Fwd_Pin, 0);
				  HAL_GPIO_WritePin (GPIOC, M3_Back_Pin, 1);
				  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, crr);
				  motor_direction[Front_Right] = -1;
			  }
			  break;

		  case Mid_Right:
			  if (speed == 0){
				  HAL_GPIO_WritePin (GPIOC, M4_Fwd_Pin, 0);
				  HAL_GPIO_WritePin (GPIOC, M4_Back_Pin, 0);
				  motor_direction[Mid_Right] = 0;
			  }
			  else if (!is_backwards){
				  HAL_GPIO_WritePin (GPIOC, M4_Fwd_Pin, 1);
				  HAL_GPIO_WritePin (GPIOC, M4_Back_Pin, 0);
				  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, crr);
				  motor_direction[Mid_Right] = 1;
			  }
			  else{
				  HAL_GPIO_WritePin (GPIOC, M4_Fwd_Pin, 0);
				  HAL_GPIO_WritePin (GPIOC, M4_Back_Pin, 1);
				  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, crr);
				  motor_direction[Mid_Right] = -1;
			  }
			  break;

		  case Back_Right:
			  if (speed == 0){
				  HAL_GPIO_WritePin (GPIOC, M5_Fwd_Pin, 0);
				  HAL_GPIO_WritePin (GPIOC, M5_Back_Pin, 0);
				  motor_direction[Back_Right] = 0;
			  }
			  else if (!is_backwards){
				  HAL_GPIO_WritePin (GPIOC, M5_Fwd_Pin, 1);
				  HAL_GPIO_WritePin (GPIOC, M5_Back_Pin, 0);
				  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, crr);
				  motor_direction[Back_Right] = 1;
			  }
			  else{
				  HAL_GPIO_WritePin (GPIOC, M5_Fwd_Pin, 0);
				  HAL_GPIO_WritePin (GPIOC, M5_Back_Pin, 1);
				  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, crr);
				  motor_direction[Back_Right] = -1;
			  }
			  break;
	  }
  }

  void serial_processing (char *buffer) {
	  //Example command: $set_speed(3,76)\n\r\0
	  //Set motor 3 to 76%

    char motor_id_cmd;
    int speed_cmd;

    char *ptr = strstr(buffer, "$set_speed");
    char *ptr2 = strstr(buffer, "$get_speed");

    if (ptr != NULL){
		if(sscanf(ptr, "$set_speed(%c,%d)", &motor_id_cmd, &speed_cmd) == 2){

		  if (speed_cmd > 100 || speed_cmd < -100){
			return;
		  }

		  switch(motor_id_cmd){

			case 'L': //Left Side
			  for (int i = 0; i < 3; i++) {
				update_motor(i, speed_cmd);
			  }
			  break;

			case 'R': //Right side
			  for(int i = 3; i < 6; i++) {
				update_motor(i, speed_cmd);
			  }
			  break;

			case 'A': //All motors
			  for ( int i = 0; i < 6; i++) {
				update_motor(i, speed_cmd);
			  }
			  break;

			case 'S': //Emergency stop
			  for (int i = 0; i < 6; i++) {
			  update_motor(i, 0); //Set all motors to 0
			  }
			  break;

			default: //Individual motor 0 - 5
			  int motor_id = motor_id_cmd - '0';

			  if (motor_id <= 5 && motor_id >= 0) {
				update_motor(motor_id, speed_cmd);
			  }
			  break;
		  }
		}
    }

    if (ptr2 != NULL){
        char motor_id_cmd2;
        if(sscanf(ptr2, "$get_speed(%c)", &motor_id_cmd2) == 1){
            int motor_id = motor_id_cmd2 - '0';

            if (motor_id >= 0 && motor_id <= 5){
            	__disable_irq();
            	encoder_counts[motor_id] = 0;
            	__enable_irq();

                rpm_pending_motor = motor_id;
                rpm_window_start = HAL_GetTick();
                last_speed_calc_tick[motor_id] = rpm_window_start;
                rpm_state = RPM_MEASURING;
            }
        }
    }
  }

  void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
	  if (huart->Instance == USART2) {

		  if (!msg_ready) {
			  if (rx_char == '\n' || rx_char == '\r') {
				  if (rx_index > 0) {
					  rx_buffer[rx_index] = '\0';
					  msg_ready = 1;
					  rx_index = 0;
				  }
			  }

			  else if (rx_char == '\b' || rx_char == 0x7F) {
				  if (rx_index > 0) {
					  rx_index--; // Step back one character in the buffer
				  }
			  }
			  else if (rx_index < 63) {
				  rx_buffer[rx_index++] = rx_char;
			  }
		  }
		  HAL_UART_Receive_IT(&huart2, (uint8_t *)&rx_char, 1);
	  }
	}

  void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart) {
      if (huart->Instance == USART2) {
          // Clear the error flags and restart reception so the board doesn't lock up
          __HAL_UART_CLEAR_OREFLAG(huart);
          HAL_UART_Receive_IT(&huart2, (uint8_t *)&rx_char, 1);
      }
  }

  void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
	  if (GPIO_Pin == M0_EXTI_Pin) encoder_counts[0]++;
	  else if (GPIO_Pin == M1_EXTI_Pin) encoder_counts[1]++;
	  else if (GPIO_Pin == M2_EXTI_Pin) encoder_counts[2]++;
	  else if (GPIO_Pin == M3_EXTI_Pin) encoder_counts[3]++;
	  else if (GPIO_Pin == M4_EXTI_Pin) encoder_counts[4]++;
	  else encoder_counts[5]++;
  }

  void calculate_rpm(int motor_id) {
      uint32_t now = HAL_GetTick(); // milliseconds
      uint32_t elapsed_ms = now - last_speed_calc_tick[motor_id];

      if (elapsed_ms == 0) return;

      // Snapshot and reset count atomically
      __disable_irq();
      uint32_t counts = encoder_counts[motor_id];
      encoder_counts[motor_id] = 0;
      __enable_irq();

      last_speed_calc_tick[motor_id] = now;

      // RPM = (counts / PPR) / (elapsed_ms / 60000)
      motor_rpm[motor_id] = ((double)counts / ENCODER_PPR) * (60000.0f / elapsed_ms);
  }
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
